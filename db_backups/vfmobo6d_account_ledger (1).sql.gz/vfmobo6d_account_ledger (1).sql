-- MySQL dump 10.13  Distrib 5.6.33-79.0, for Linux (x86_64)
--
-- Host: localhost    Database: vfmobo6d_account_ledger
-- ------------------------------------------------------
-- Server version	5.6.33-79.0-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `accounts`
--

DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `full_name` varchar(250) NOT NULL,
  `name` varchar(250) NOT NULL,
  `parent_account_id` int(11) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `notes` varchar(250) DEFAULT NULL,
  `commodity_type` varchar(50) DEFAULT NULL,
  `commodity_value` varchar(50) DEFAULT NULL,
  `owner_id` int(11) NOT NULL,
  PRIMARY KEY (`account_id`),
  UNIQUE KEY `account_id_UNIQUE` (`account_id`),
  KEY `parent_account_id` (`parent_account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accounts`
--

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
INSERT INTO `accounts` (`account_id`, `full_name`, `name`, `parent_account_id`, `account_type`, `notes`, `commodity_type`, `commodity_value`, `owner_id`) VALUES (1,'Assets','Assets',0,'ASSET',NULL,'INR','CURRENCY',0),(2,'Assets:Demonition Collection','Demonition Collection',1,'CASH',NULL,'INR','CURRENCY',0),(3,'Assets:Cash in Wallet','Cash in Wallet',1,'ASSET',NULL,'INR','CURRENCY',0),(4,'Assets:Savings Accounts, Punjab National Bank, Tirur','Savings Accounts, Punjab National Bank, Tirur',1,'BANK',NULL,'INR','CURRENCY',0),(5,'Receivable Assets','Receivable Assets',0,'RECEIVABLE',NULL,'INR','CURRENCY',0),(6,'Receivable Assets:Commission Works, Laptop Repair, Positive Computers, Sharafu Kaka Lottery System - Display Replacements','Commission Works, Laptop Repair, Positive Computers, Sharafu Kaka Lottery System - Display Replacements',5,'RECEIVABLE',NULL,'INR','CURRENCY',0),(7,'Receivable Assets:Misc., EDC','Misc., EDC',5,'RECEIVABLE',NULL,'INR','CURRENCY',0),(8,'Receivable Assets:Misc., EDC:E-Labs, Introduction to Github Repository','E-Labs, Introduction to Github Repository',7,'RECEIVABLE',NULL,'INR','CURRENCY',0),(9,'Receivable Assets:Misc., EDC:E-Labs, Introduction to Github Repository:Food','Food',8,'RECEIVABLE',NULL,'INR','CURRENCY',0),(10,'Receivable Assets:Misc., EDC:E-Labs, Introduction to Github Repository:Food:Lunch','Lunch',9,'RECEIVABLE',NULL,'INR','CURRENCY',0),(11,'Receivable Assets:Misc., EDC:E-Labs, Introduction to Github Repository:Food:Snacks','Snacks',9,'RECEIVABLE',NULL,'INR','CURRENCY',0),(12,'Receivable Assets:Misc., EDC:E-Labs, Introduction to Github Repository:Transporation, Public, Bus Fair','Transporation, Public, Bus Fair',8,'RECEIVABLE',NULL,'INR','CURRENCY',0),(13,'Receivable Assets:Misc., EDC:Excellencia 17 - MES Kuttippuram','Excellencia 17 - MES Kuttippuram',7,'RECEIVABLE',NULL,'INR','CURRENCY',0),(14,'Receivable Assets:Misc., EDC:Excellencia 17 - MES Kuttippuram:Food, Snacks','Food, Snacks',13,'RECEIVABLE',NULL,'INR','CURRENCY',0),(15,'Receivable Assets:Misc., EDC:Excellencia 17 - MES Kuttippuram:Transporation, Public, Bus Fair','Transporation, Public, Bus Fair',13,'RECEIVABLE',NULL,'INR','CURRENCY',0),(16,'Receivable Assets:Misc., EDC:Web Application Development using Laravel Workshop with Git Repository - 2 Days Workshop - MES Kuttippuram, Transporation, Public, Bus Fair','Web Application Development using Laravel Workshop with Git Repository - 2 Days Workshop - MES Kuttippuram, Transporation, Public, Bus Fair',7,'RECEIVABLE',NULL,'INR','CURRENCY',0),(17,'Receivable Assets:People Debits','People Debits',5,'RECEIVABLE',NULL,'INR','CURRENCY',0),(18,'Receivable Assets:People Debits:Aflah S 4 CS CCET Valanchery','Aflah S 4 CS CCET Valanchery',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(19,'Receivable Assets:People Debits:Ajmal S 5 CS CCET Valanchery','Ajmal S 5 CS CCET Valanchery',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(20,'Receivable Assets:People Debits:Akhil S 4 CS CCET Valanchery','Akhil S 4 CS CCET Valanchery',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(21,'Receivable Assets:People Debits:Athif Mohammed, Conut Co-Works','Athif Mohammed, Conut Co-Works',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(22,'Receivable Assets:People Debits:Bari S 5 CS CCET Valanchery','Bari S 5 CS CCET Valanchery',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(23,'Receivable Assets:People Debits:Favas S 5 CS CCET Valanchery','Favas S 5 CS CCET Valanchery',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(24,'Receivable Assets:People Debits:Hajara Beegam PV Mother Banee Ishaque K','Hajara Beegam PV Mother Banee Ishaque K',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(25,'Receivable Assets:People Debits:Immutty, Mimoonathatha, Ayalvasi, Jaram','Immutty, Mimoonathatha, Ayalvasi, Jaram',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(26,'Receivable Assets:People Debits:Ismail K Father Banee Ishaque K','Ismail K Father Banee Ishaque K',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(27,'Receivable Assets:People Debits:Muhsin Mohammed PC Eazhur, Reseller Club Payments','Muhsin Mohammed PC Eazhur, Reseller Club Payments',17,'RECEIVABLE',NULL,'INR','CURRENCY',0),(28,'Receivable Assets:People Debits:Muhsin Mohammed PC Eazhur, Reseller Club Payments:Food','Food',27,'RECEIVABLE',NULL,'INR','CURRENCY',0),(29,'Receivable Assets:People Debits:Muhsin Mohammed PC Eazhur, Reseller Club Payments:Misc.','Misc.',27,'RECEIVABLE',NULL,'INR','CURRENCY',0),(30,'Receivable Assets:People Debits:Naqeeb Abdul Gafoor Peringodan, Paravanoor','Naqeeb Abdul Gafoor Peringodan, Paravanoor',17,'RECEIVABLE',NULL,'INR','CURRENCY',0);
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `configuration`
--

DROP TABLE IF EXISTS `configuration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `configuration` (
  `system_status` tinyint(4) NOT NULL,
  `version_code` int(11) NOT NULL,
  `version_name` double NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `configuration`
--

LOCK TABLES `configuration` WRITE;
/*!40000 ALTER TABLE `configuration` DISABLE KEYS */;
INSERT INTO `configuration` (`system_status`, `version_code`, `version_name`, `id`) VALUES (1,1,1,1);
/*!40000 ALTER TABLE `configuration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transactions`
--

DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_date_time` datetime NOT NULL,
  `particulars` varchar(150) NOT NULL,
  `amount` double NOT NULL,
  `insertion_date_time` datetime NOT NULL,
  `inserter_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=147 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transactions`
--

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` (`id`, `event_date_time`, `particulars`, `amount`, `insertion_date_time`, `inserter_id`) VALUES (1,'2018-01-24 16:00:00','Debit : Lunch - Tea + Ullivada x 2',24,'2018-01-25 01:12:51',0),(2,'2018-01-24 16:30:00','Debit : Achar',1,'2018-01-25 01:13:12',0),(3,'2018-01-24 19:00:00','Credit : From Mahin for Achar',5,'2018-01-25 01:13:48',0),(4,'2018-01-24 19:05:00','Debit : Achar x 5',5,'2018-01-25 01:14:12',0),(5,'2018-01-24 20:00:00','Debit : Tazhepalam - Ptu Auto Fair',10,'2018-01-25 01:14:36',0),(6,'2018-01-24 09:00:00','Credit : Initial Balance',3361,'2018-01-25 01:16:31',0),(7,'2018-01-24 20:30:00','Debit : To Mother from Semithatha Debit',1000,'2018-01-25 01:17:03',0),(8,'2018-01-25 10:00:00','Debit : To Mother for Oil, Thakkali',100,'2018-01-26 10:51:53',0),(9,'2018-01-25 16:00:00','Credit : Balance from mother on Oil, Thakkali purchase',50,'2018-01-26 10:52:33',0),(10,'2018-01-26 08:30:00','Debit : Missing',5,'2018-01-26 10:52:51',0),(11,'2018-01-26 09:30:00','Debit : Puthentheru to tirur bus fair',9,'2018-01-27 08:37:31',0),(12,'2018-01-26 09:00:00','Debit : TIRUR to PRISM bus fair',7,'2018-01-27 08:37:59',0),(13,'2018-01-26 14:00:00','Debit : Lunch : chapathi + chicken curry with ADIL & PRANAV',20,'2018-01-27 08:38:59',0),(14,'2018-01-27 10:00:00','Debit : Mother for gas',800,'2018-01-28 08:11:08',0),(15,'2018-01-27 10:05:00','Debit : Mubithatha credit',100,'2018-01-28 08:11:31',0),(16,'2018-01-28 08:00:00','Debit : Mother for SHAMSU PUTHENPURA SUHAIL KUTTIPPURAM marriage - from Semithatha debit',500,'2018-01-28 08:13:18',0),(17,'2018-01-28 15:30:00','Debit : PUTHENTHERU to tirur bus fair ',9,'2018-01-29 01:31:03',0),(18,'2018-01-28 15:40:00','Debit : TIRUR to POLY bus fair ',6,'2018-01-29 01:31:28',0),(19,'2018-01-28 15:45:00','Debit : Lunch tea + bonda X 2',24,'2018-01-29 01:31:58',0),(20,'2018-01-28 16:05:00','Debit : Achar',1,'2018-01-29 01:32:13',0),(21,'2018-01-28 22:00:00','Debit : THAZHEPALAM to puthentheru bus fair ',10,'2018-01-29 01:32:47',0),(24,'2018-02-01 08:08:00','Credit : from sharafu kaka lottery work - automation through WhatsApp : combination of LSK & Stright pattern',500,'2018-02-01 10:01:05',0),(25,'2018-02-01 08:08:30','Debit : Mother for puthentheru palli committee piriv (Nov - 40 + Dec - 40 + Jan - 60 + Feb - 60)',200,'2018-02-01 10:02:47',0),(26,'2018-02-01 14:14:00','Debit : PUTHENTHERU to tirur bus fair ',9,'2018-02-02 09:24:07',0),(27,'2018-02-01 14:30:30','Debit : TIRUR to PRISM bus fair ',7,'2018-02-02 09:24:26',0),(28,'2018-02-01 19:19:00','Debit : THAZHEPALAM to puthentheru bus fair ',10,'2018-02-02 09:24:53',0),(29,'2018-02-02 12:12:00','Debit : PUTHENTHERU to tirur ',9,'2018-02-06 08:56:24',0),(30,'2018-02-02 12:25:25','Debit : to PNB',1000,'2018-02-06 08:56:49',0),(31,'2018-02-02 12:30:30','Debit : TIRUR to PRISM ',7,'2018-02-06 08:57:10',0),(32,'2018-02-02 15:15:00','Debit : Lunch tea + samoosa',15,'2018-02-06 08:57:39',0),(33,'2018-02-02 15:30:30','Debit : achar X 2',2,'2018-02-06 08:57:52',0),(34,'2018-02-02 19:00:00','Debit : tirur to puthentheru ',9,'2018-02-06 08:58:23',0),(35,'2018-02-02 19:19:25','Credit : from pnb',500,'2018-02-06 08:58:39',0),(36,'2018-02-02 19:30:30','Debit : pattani',30,'2018-02-06 08:58:53',0),(37,'2018-02-03 09:09:00','Debit : TIRUR to PRISM ',7,'2018-02-06 09:01:04',0),(38,'2018-02-03 19:19:00','Debit : THAZHEPALAM to puthentheru ',10,'2018-02-06 09:01:31',0),(39,'2018-02-03 19:39:30','Debit : pattani ',30,'2018-02-06 09:01:45',0),(40,'2018-02-04 08:08:00','Debit : to hisham for remote and remote cover',200,'2018-02-06 09:03:18',0),(41,'2018-02-04 16:16:00','Credit : from hisham remote and remote cover credit, travel expense to tirur with shemeem - Rs. 30 - Total given - 200, Balance - 200-30 =170',170,'2018-02-06 09:04:03',0),(42,'2018-02-04 09:09:00','Debit : PUTHENTHERU to tirur ',9,'2018-02-06 09:04:24',0),(43,'2018-02-04 09:30:30','Debit : TIRUR to K G Padi Basil Work',7,'2018-02-06 09:04:37',0),(44,'2018-02-04 12:12:00','Debit : THAZHEPALAM to puthentheru ',9,'2018-02-06 09:04:59',0),(45,'2018-02-05 10:10:00','Debit : to mother for semithatha',200,'2018-02-06 09:05:27',0),(46,'2018-02-05 13:13:00','Credit : from sharafu kaka lottery work server maintenance',2000,'2018-02-06 09:06:05',0),(49,'2018-02-04 09:08:00','Debit : to mother for THALAKKADATHOOR travel expenses',100,'2018-02-06 09:10:43',0),(51,'2018-02-06 09:09:00','Credit : extra 1.50',1.5,'2018-02-06 09:15:41',0),(59,'2018-02-06 10:11:30','Debit : to PNB ',2000,'2018-02-23 10:13:15',0),(60,'2018-02-06 10:12:30','Debit : Lunch with SHIVADASAN sir, surjith, pranav, adil & nisar - win 10 & Ubuntu installation ',50,'2018-02-23 10:14:30',0),(58,'2018-02-06 10:10:30','Debit : PUTHENTHERU to tirur ',9,'2018-02-23 10:13:04',0),(61,'2018-02-06 14:10:30','Credit : from pranav for achar',1,'2018-02-23 10:18:26',0),(62,'2018-02-06 14:15:30','Debit : avmchar X 2',2,'2018-02-23 10:18:54',0),(63,'2018-02-06 14:20:30','Credit : from prism',100,'2018-02-23 10:19:15',0),(64,'2018-02-06 14:25:30','Debit : barbershop ',70,'2018-02-23 10:19:35',0),(65,'2018-02-06 14:30:30','Debit : TIRUR to puthentheru ',10,'2018-02-23 10:19:54',0),(66,'2018-02-06 14:35:30','Credit : from pnb',500,'2018-02-23 10:20:11',0),(67,'2018-02-06 14:40:30','Debit : pattani ',30,'2018-02-23 10:20:47',0),(68,'2018-02-07 08:51:01','Debit : to college with VYSHAK - series exam previous day - petrol change ',100,'2018-02-26 12:52:18',0),(69,'2018-02-07 09:51:01','Debit : Coffee + kadi',18,'2018-02-26 12:53:39',0),(70,'2018-02-07 10:53:45','Debit : SREELAKSHMI COCHIN metayi  (mango bytes )X 2',2,'2018-02-26 12:54:56',0),(71,'2018-02-07 11:53:45','Debit : To UMMU KULSU for compiler assignment ',10,'2018-02-26 12:55:37',0),(72,'2018-02-07 12:53:45','Debit : perakka X 2 -on return from bekkarikaran (Kiran friend ) enna delivery ',10,'2018-02-26 12:57:34',0),(73,'2018-02-07 13:53:45','Debit : Milk cake VYSHAK  -on return from bekkarikaran (Kiran friend ) enna delivery',5,'2018-02-26 12:58:07',0),(74,'2018-02-07 14:53:45','Debit : bakery for work from VAILATHUR ',30,'2018-02-26 12:58:59',0),(75,'2018-02-08 08:53:45','Debit : to college with VYSHAK - series exam ',100,'2018-02-26 13:00:42',0),(76,'2018-02-08 09:53:45','Debit : pen',5,'2018-02-26 13:01:05',0),(77,'2018-02-08 10:53:45','Debit : tea - coffee - parippuvada',26,'2018-02-26 13:01:37',0),(78,'2018-02-08 11:53:45','Debit : metayi X 2',4,'2018-02-26 13:01:57',0),(79,'2018-02-08 12:53:45','Debit : ziyad metayi ',5,'2018-02-26 13:02:15',0),(80,'2018-02-08 13:53:45','Debit : enthakka X 5 ',5,'2018-02-26 13:02:40',0),(81,'2018-02-08 14:53:45','Debit : to akhil debit ',100,'2018-02-26 13:03:10',0),(82,'2018-02-09 08:53:45','Debit : tea - parippuvada- coffee balance 6 by VYSHAK',20,'2018-02-26 13:05:23',0),(83,'2018-02-09 08:55:45','Debit : surkka achar lunch',5,'2018-02-26 13:05:42',0),(84,'2018-02-09 09:53:45','Credit : from aflah ',100,'2018-02-26 13:06:12',0),(85,'2018-02-09 10:53:45','Debit : beef - poratta - pathiri x3 ',71.5,'2018-02-26 13:07:34',0),(86,'2018-02-09 11:53:45','Credit : from atm',2000,'2018-02-26 13:07:56',0),(87,'2018-02-09 12:53:45','Debit : surkka achar X 2',10,'2018-02-26 13:08:15',0),(88,'2018-02-09 13:50:45','Debit : to VYSHAK for aflah credit ',100,'2018-02-26 13:10:27',0),(89,'2018-02-09 13:53:45','Debit : pump enna credit ',100,'2018-02-26 13:10:57',0),(90,'2018-02-09 14:53:45','Debit : VYSHAK enna - next day too',150,'2018-02-26 13:11:25',0),(91,'2018-04-28 17:00:51','Credit : Initial Balance',1345.5,'2018-04-28 17:25:39',1),(92,'2018-04-28 22:30:54','Debit : To NAVEEN AUTOMOBILE EVENING 2015 BATCH SSM POLY TIRUR as loan ',10,'2018-04-29 10:04:03',1),(93,'2018-04-29 19:15:04','Debit : By hisham for things - muda and vegetables',35,'2018-04-29 19:37:51',1),(94,'2018-04-29 20:00:04','Debit : barbershop saleem for shave',50,'2018-04-30 08:26:45',1),(95,'2018-04-30 07:00:04','Debit : to mother for Barahath expenses ',100,'2018-04-30 08:28:06',1),(96,'2018-04-30 08:00:04','Debit : VYSHAK petrol to college for compiler exam',120,'2018-04-30 08:28:43',1),(97,'2018-04-30 09:00:44','Debit : tea at college canteen ',8,'2018-05-01 11:10:28',1),(98,'2018-04-30 09:05:44','Debit : PEN for exam',10,'2018-05-01 11:10:51',1),(99,'2018-04-30 12:00:44','Debit : Lunch - BIRIYANI ',50,'2018-05-01 11:12:00',1),(100,'2018-04-30 17:00:44','Credit : from VYSHAK to transfer to aflah account ',2300,'2018-05-01 11:12:53',1),(101,'2018-05-01 08:00:44','Debit : hisham for mudi vettal (actual 50, previous 50)',100,'2018-05-01 11:18:27',1),(102,'2018-05-01 08:05:44','Debit : Mother for things ( to JAMEELATATHA for curtain transportation vehicle charge loan - 30)',50,'2018-05-01 11:20:21',1),(103,'2018-05-01 10:30:44','Debit : PUTHENTHERU to tirur for poly pm class',10,'2018-05-01 11:24:51',1),(104,'2018-05-01 11:00:44','Debit : TIRUR to POLY for poly pm class',8,'2018-05-01 11:25:19',1),(105,'2018-05-01 14:00:20','Credit : from salam sir on pm class lunch balance ( 10 on his calculation - actual : 110 )',110,'2018-05-02 11:51:05',1),(106,'2018-05-02 10:00:20','Debit : Mother for PUTHENTHERU palli piriv',60,'2018-05-02 11:51:48',1),(107,'2018-05-10 08:00:44','Credit : Initial Balance',4062,'2018-05-10 20:11:44',2),(108,'2018-05-10 09:00:44','Debit : soudam to vettichira',20,'2018-05-10 20:14:52',2),(109,'2018-05-10 10:00:44','Debit : vettichira to VALANCHERY ',10,'2018-05-10 20:16:11',2),(110,'2018-05-10 10:30:44','Debit : carrot',30,'2018-05-10 20:18:15',2),(111,'2018-05-10 11:00:44','Credit : from ziyad for food',50,'2018-05-10 20:21:09',2),(112,'2018-05-10 11:30:44','Debit : for food ( actual 154, vatti JASEEM rs.4)(bari & JAMAL 4 poratta +kari)(ziyad chapatti 5+KARI)(BANI 7+kari)',158,'2018-05-10 20:26:17',2),(113,'2018-05-10 12:30:44','Debit : ziyad vali + theeppetti + manga',10,'2018-05-10 20:27:49',2),(114,'2018-05-10 13:00:44','Credit : ziyad for breakfast',20,'2018-05-10 20:35:01',2),(115,'2018-05-11 08:00:25','Debit : breakfast (porattax2 - ziyad)(porattax2 - chaya -mutta kari-dk)',60,'2018-05-11 20:49:50',2),(116,'2018-05-11 09:00:25','Debit : to akhil for his fee',1600,'2018-05-11 20:50:31',2),(117,'2018-05-11 12:30:25','Debit : to ziyad for petrol',40,'2018-05-11 20:51:05',2),(118,'2018-05-11 14:00:25','Debit : valiya kunnu to valanchery',7,'2018-05-11 20:51:29',2),(119,'2018-05-11 14:30:25','Debit : valanchery to tirur',20,'2018-05-11 20:51:52',2),(120,'2018-05-11 15:30:25','Debit : tirur to puthentheru',10,'2018-05-11 20:52:13',2),(121,'2018-05-11 12:00:25','Debit : to jaseem for bike repair',500,'2018-05-11 20:53:03',2),(122,'2018-05-12 09:00:36','Debit : Mother for poratta - no thenga onakkal for dk',100,'2018-05-14 09:44:22',2),(123,'2018-05-13 09:00:36','Debit : HISHAM for poratta',20,'2018-05-14 09:44:51',2),(124,'2018-05-13 19:00:36','Debit : Mother for swalath',10,'2018-05-14 09:45:15',2),(125,'2018-05-13 12:00:36','Debit : insha for mitayi',2,'2018-05-14 09:45:56',2),(126,'2018-05-13 17:00:53','Debit : shortage',10,'2018-05-16 17:37:06',2),(127,'2018-05-14 17:00:53','Credit : hisham returns his poratta loan',20,'2018-05-16 17:37:46',2),(128,'2018-05-15 17:00:53','Debit : SHIHAB KAMMU kaka jaram as credit',1500,'2018-05-16 17:38:20',2),(129,'2018-05-16 17:00:07','Debit : soudam to VAILATHOOR ',8,'2018-05-18 12:17:51',2),(130,'2018-05-16 18:00:07','Debit : VAILATHOOR to VALANCHERY ',17,'2018-05-18 12:18:48',2),(131,'2018-05-16 19:00:07','Debit : VALANCHERY to pookattiri',8,'2018-05-18 12:19:47',2),(132,'2018-05-17 08:00:07','Credit : from pnb',500,'2018-05-18 12:20:21',2),(133,'2018-05-17 15:30:07','Debit : Akhil debit - breakfast  (poratta x2+muttakkari) with ziyad  (poratta x2 + muttakkari ) and akhil (poratta x2)',90,'2018-05-18 12:21:51',2),(134,'2018-05-17 12:00:07','Credit : from FAVAS S 6 COMPUTER COCHIN COLLEGE VALANCHERY ',10,'2018-05-18 12:22:25',2),(135,'2018-05-17 13:00:07','Credit : from bari S6 computer COCHIN college VALANCHERY ',20,'2018-05-18 12:22:59',2),(136,'2018-05-17 14:00:07','Credit : from JAMAL S 6 COMPUTER COCHIN COLLEGE VALANCHERY ',20,'2018-05-18 12:23:22',2),(137,'2018-05-17 15:00:07','Credit : from aflah S 6 COMPUTER COCHIN COLLEGE VALANCHERY ',50,'2018-05-18 12:24:23',2),(138,'2018-05-17 16:00:07','Debit : to FAVAS S 6 COMPUTER COCHIN COLLEGE VALANCHERY ',10,'2018-05-18 12:24:53',2),(139,'2018-05-17 18:00:07','Debit : TIRUR to VATTATHANI auto fair',10,'2018-05-18 12:25:34',2),(140,'2018-05-18 10:00:07','Credit : from hisham for demolition ',50,'2018-05-18 12:27:07',2),(141,'2018-05-18 11:00:07','Debit : PUTHENTHERU to tirur ',10,'2018-05-18 12:27:29',2),(142,'2018-05-18 12:36:35','Debit : to pnb',500,'2018-05-18 23:36:53',2),(143,'2018-05-18 13:36:35','Debit : TIRUR to prism',8,'2018-05-18 23:37:17',2),(144,'2018-05-18 14:36:35','Debit : PRISM to tirur',8,'2018-05-18 23:37:43',2),(145,'2018-05-18 15:36:35','Debit : TIRUR to PUTHENTHERU ',10,'2018-05-18 23:38:08',2),(146,'2018-05-18 17:36:35','Credit : from sharafudheen VALPARAMBIL jaram',300,'2018-05-18 23:38:43',2);
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`) VALUES (0,'baneeishaque','9895204814'),(1,'banee_28_4','9895204814'),(2,'banee_10_5','9895204814');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'vfmobo6d_account_ledger'
--

--
-- Dumping routines for database 'vfmobo6d_account_ledger'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-21 19:12:20
